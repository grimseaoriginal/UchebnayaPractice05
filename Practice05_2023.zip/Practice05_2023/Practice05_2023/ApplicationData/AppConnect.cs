﻿using Practice05_2023.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice05_2023.ApplicationData
{
    internal class AppConnect
    {
        public static st64Entities1 model0db;
    }
}
    