﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice05_2023.ApplicationData;
using Practice05_2023.DataModels;

namespace Practice05_2023.Pages
{
    /// <summary>
    /// Логика взаимодействия для MandatePage.xaml
    /// </summary>
    public partial class MandatePage : Page
    {
        private string userName;
        public MandatePage(string firstName)
        {
            InitializeComponent();
            DGridInfo.ItemsSource = st64Entities1.GetContext().Users.ToList();
            myLable.Content = firstName;

            userName = firstName;
        }

        private void GoToPageVerif_Click(object sender, RoutedEventArgs e)
        {
            string firstName = userName;
            PageVerification pageVerif = new PageVerification(firstName);
            this.NavigationService.Navigate(pageVerif);
        }

        private void GoToMandatPage_Click(object sender, RoutedEventArgs e)
        {
            string firstName = userName;
            MandatePage mandate = new MandatePage(firstName);
            this.NavigationService.Navigate(mandate);
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Одобрено","Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void finishWork_btn_Click(object sender, RoutedEventArgs e)
        {
            AuthPage mainPage = new AuthPage();
            this.NavigationService.Navigate(mainPage);
        }
    }
}
