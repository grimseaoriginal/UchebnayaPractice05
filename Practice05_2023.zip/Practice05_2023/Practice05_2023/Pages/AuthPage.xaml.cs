﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice05_2023.Pages;
using System.Data.Sql;
using Practice05_2023.ApplicationData;
using Practice05_2023.DataModels;

namespace Practice05_2023.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }

        private void entertoSystemButton_Click(object sender, RoutedEventArgs e)
        {
            Auth();
        }

        private void Auth()
        {
            string choosenRole;
            choosenRole = typeOfUser_comboBox.Text;

            if (string.IsNullOrEmpty(loginTextBox.Text) || string.IsNullOrEmpty(passTextBox.Text))
            {
                MessageBox.Show("Введите логин и пароль.");
                return;
            }

            try
            {
                var db = AppConnect.model0db;


                Employees userObj = db.Employees.FirstOrDefault(x => x.Логин == loginTextBox.Text && x.Пароль == passTextBox.Text);
                if (userObj == null)
                {
                    MessageBox.Show("Неправильно набран пользователь!", "Авторзация не верна", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    switch (choosenRole)
                    {
                        case "Администратор доступа":
                            MessageBox.Show("Здраствуйте " + userObj.ФИО + "!",
                         "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                            AddNewUserByAdmin adm = new AddNewUserByAdmin();
                            this.NavigationService.Navigate(adm);
                            break;
                        case "Специалист по ИБ":
                            MessageBox.Show("Здраствуйте " + userObj.ФИО + "!",
                         "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                            ChoosingUser chos = new ChoosingUser();
                            this.NavigationService.Navigate(chos);
                            break;
                        case "Руководитель отдела":
                            MessageBox.Show("Здраствуйте " + userObj.ФИО + "!",
                         "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                            MandatePage choss = new MandatePage(userObj.ФИО);
                            this.NavigationService.Navigate(choss);
                            break;
                        case "Обычный пользователь":
                            MessageBox.Show("Здраствуйте " + userObj.ФИО + "!",
                         "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                            ChoosingUser chosss = new ChoosingUser();
                            this.NavigationService.Navigate(chosss);
                            break;
                    }
                }


            }
            catch (Exception Ex)
            {
                MessageBox.Show("Ошибка " + Ex.Message.ToString() + "Критическая ошибка !", "Уведомления", MessageBoxButton.OK, MessageBoxImage.Warning);

            }
        }
    }
}
