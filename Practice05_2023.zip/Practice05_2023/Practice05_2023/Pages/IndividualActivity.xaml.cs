﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice05_2023.DataModels;
using Practice05_2023.ApplicationData;

namespace Practice05_2023.Pages
{
    /// <summary>
    /// Логика взаимодействия для IndividualActivity.xaml
    /// </summary>
    public partial class IndividualActivity : Page
    {
        string userFIO;
        public IndividualActivity()
        {
            InitializeComponent();
            cmbCel.Items.Add("Причина 1");
            cmbCel.Items.Add("Причина 2");
            cmbPodr.Items.Add("ИБ");
            cmbPodr.Items.Add("ПОП");
            cmbPodr.Items.Add("МО");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        public void AddUser()
        {
            try
            {
                userFIO = famil.Text + " " + ima.Text + " " + otchestvo.Text;
                var parsedDate = DateTime.Parse(dateRojd.ToString());
                var startedDate = DateTime.Parse(startDate.ToString());
                var finishedDate = DateTime.Parse(stopDate.ToString());

                UsersPrivateActivity userObj = new UsersPrivateActivity()
                {
                    ФИО = userFIO,
                    Номер_телефона = tel.Text,
                    Email = email.Text,
                    Организация = org.Text,
                    Примечание = prim.Text,
                    Дата_рождения = parsedDate,
                    Серия_паспорта = int.Parse(ser.Text.ToString()),
                    Номер_паспорта = int.Parse(num.Text.ToString()),
                    Срок_начала = startedDate,
                    Срок_окончания = finishedDate
                };
                AppConnect.model0db.UsersPrivateActivity.Add(userObj);
                AppConnect.model0db.SaveChanges();
                MessageBox.Show("Данные успешно добавлены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Ошибка " + Ex.Message.ToString() + "Критическая ошибка !", "Уведомления", MessageBoxButton.OK, MessageBoxImage.Warning);              
            }
        }

        

        private void applyTicket_btn_Click(object sender, RoutedEventArgs e)
        {
            AddUser();
        }

        private void cleanForm_btn_Click(object sender, RoutedEventArgs e)
        {
            famil.Clear();
            ima.Clear();
            otchestvo.Clear();
            tel.Clear();
            email.Clear();
            org.Clear();
            prim.Clear();
            ser.Clear();
            num.Clear();
        }

        private void uploadDocument_btn_Click(object sender, RoutedEventArgs e)
        {

        }
        private void uploadPhoto_btn_Click(object sender, RoutedEventArgs e)
        {
            
        }
        private void Grid_MouseMove(object sender, MouseEventArgs e)
        {
            if (famil.Text == "" || ima.Text == "" || otchestvo.Text == "")
            {
                userFIO = "asd";
            }
            else
            {
                cleanForm_btn.IsEnabled = true;
            }
        }

        private void cmbPodr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (cmbPodr.Text)
            {
                case "ИБ":
                    FIO.Text = "Горбунов Юрин Валерианович";
                    break;
                case "МО":
                    FIO.Text = "Бобылева Жанна Петровна";
                    break;
                case "ПОП":
                    FIO.Text = "Федотов Климент Васильевич";
                    break;
            }
        }
    }
}
