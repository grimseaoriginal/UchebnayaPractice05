﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice05_2023.ApplicationData;
using Practice05_2023.DataModels;

namespace Practice05_2023.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddNewUserByAdmin.xaml
    /// </summary>
    public partial class AddNewUserByAdmin : Page
    {
        public string fioString;
        public string typeofJob;
        public AddNewUserByAdmin()
        {
            InitializeComponent();
        }

        public void AddUser()
        {
            try
            {
                switch (typeOfJob_box.Text)
                {
                    case "Администратор доступа":
                        typeofJob = "Администратор доступа";
                        break;
                    case "Специалист по ИБ":
                        typeofJob = "Служба ИБ";
                        break;
                    case "Руководитель отдела":
                        typeofJob = "Руководитель ПОП";
                        break;
                    case "Контролёр ГОЗ":
                        typeofJob = "Контролёр МО";
                        break;
                    default:
                        typeOfJob_box.Text = "Специалист по ИБ";
                        typeofJob = "Служба ИБ";
                        break;
                }
                fioString = surnameTextBox.Text + " " + firstnameTextBox.Text + " " + lastNameWordBox.Text;

                Employees userObj = new Employees()
                {
                    ФИО = fioString,
                    Пол = gender_comboBox.Text,
                    Должность = typeOfJob_box.Text,
                    Тип_пользователя = typeofJob,
                    Секретное_слово = "Щелочь",
                    Логин = firstnameTextBox.Text + "asd",
                    Пароль = lastNameWordBox.Text + "fWs"

                };
                AppConnect.model0db.Employees.Add(userObj);
                AppConnect.model0db.SaveChanges();
                MessageBox.Show("Данные успешно добавлены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch
            {
                MessageBox.Show("Ошибка при добавлении данных!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            AddUser();
            MessageBox.Show("Пользователь успешно добавлен!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void finishTheJob_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            firstnameTextBox.Clear();
            surnameTextBox.Clear();
            lastNameWordBox.Clear();
            gender_comboBox.Text = "";
            typeOfJob_box.Clear();

        }
    }
}
