﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice05_2023.DataModels;
using Practice05_2023.ApplicationData;

namespace Practice05_2023.Pages
{
    /// <summary>
    /// Логика взаимодействия для GroupActivity.xaml
    /// </summary>
    public partial class GroupActivity : Page
    {
        public string destination;
        public string passport_nums;
        public GroupActivity()
        {
            InitializeComponent();
            cmbCel.Items.Add("Причина 1");
            cmbCel.Items.Add("Причина 2");
            cmbPodr.Items.Add("ИБ");
            cmbPodr.Items.Add("ПОП");
            cmbPodr.Items.Add("МО");
        }

        public void AddUser()
        {
            try
            {
                string userFIO = famil.Text + " " + ima.Text + " " + otchestvo.Text;
                var currentDate = DateTime.Today;
                passport_nums = int.Parse(ser.Text.ToString()) + " " + int.Parse(num.Text.ToString());

                Users userObj = new Users()
                {

                    ФИО = userFIO,
                    Номер_телефона = tel.Text,
                    Данные_паспорта = passport_nums,
                    Дата_рождения = dateRojd.ToString(),
                    E_mail = email.Text,
                    Логин = ima.Text + "asd235asdg",
                    Пароль = famil.Text.ToLower() + "asd2r5",
                    Назначение = currentDate.ToString()
                    
                };
                AppConnect.model0db.Users.Add(userObj);
                AppConnect.model0db.SaveChanges();
                MessageBox.Show("Данные успешно добавлены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Ошибка " + Ex.Message.ToString() + "Критическая ошибка !", "Уведомления", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        public void AddGroupActivity()
        {
            try
            {
                string userFIO = famil.Text + " " + ima.Text + " " + otchestvo.Text;
                var parsedDate = DateTime.Parse(dateRojd.ToString());
                var startedDate = DateTime.Parse(startDate.ToString());
                var finishedDate = DateTime.Parse(stopDate.ToString());

                UsersGroupActivity userObj = new UsersGroupActivity()
                {
                    ФИО = userFIO,
                    Номер_телефона = tel.Text,
                    Email = email.Text,
                    Организация = org.Text,
                    Примечание = prim.Text,
                    Дата_рождения = parsedDate,
                    Серия_паспорта = int.Parse(ser.Text.ToString()),
                    Номер_паспорта = int.Parse(num.Text.ToString()),
                    Срок_начала = startedDate,
                    Срок_окончания = finishedDate
                };
                AppConnect.model0db.UsersGroupActivity.Add(userObj);
                AppConnect.model0db.SaveChanges();
                MessageBox.Show("Данные успешно добавлены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Ошибка " + Ex.Message.ToString() + "Критическая ошибка!", "Уведомления", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void comebackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        private void done_btn_Click(object sender, RoutedEventArgs e)
        {
            AddGroupActivity();
        }

        private void Grid_MouseMove(object sender, MouseEventArgs e)
        {
            if (famil.Text == "" || ima.Text == "" || otchestvo.Text == "")
            {
                string suserFIO = "asd";
            }
            else
            {
                clean_btn.IsEnabled = true;
            }
        }

        private void cmbPodr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (cmbPodr.Text)
            {
                case "ИБ":
                    FIO.Text = "Горбунов Юрин Валерианович";
                    break;
                case "МО":
                    FIO.Text = "Бобылева Жанна Петровна";
                    break;
                case "ПОП":
                    FIO.Text = "Федотов Климент Васильевич";
                    break;
            }
        }

        private void addUser_btn_Click(object sender, RoutedEventArgs e)
        {
            AddUser();
        }

        private void download_btn_Click(object sender, RoutedEventArgs e)
        {
            DGridKlients.ItemsSource = st64Entities1.GetContext().Users.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void clean_btn_Click(object sender, RoutedEventArgs e)
        {
            famil.Clear();
            ima.Clear();
            otchestvo.Clear();
            tel.Clear();
            email.Clear();
            org.Clear();
            prim.Clear();
            ser.Clear();
            num.Clear();
        }
    }
}
