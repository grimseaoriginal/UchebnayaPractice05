﻿using Microsoft.AspNetCore.Mvc;

namespace IDZ.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        // GET: api/Employee
        [HttpGet]
        public IEnumerable<Employees> Get()
        {
            return GetEmployees();
        }
        // GET: api/Employee/5
        [HttpGet("{id}", Name = "Get")]
        public Employees Get(int id)
        {
            return GetEmployees().Find(e => e.Id == id);
        }
        // POST: api/Employee
        [HttpPost]
        [Produces("application/json")]
        public Employees Post([FromBody] Employees employee)
        {
            // Logic to create new Employee
            return new Employees();
        }
        // PUT: api/Employee/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Employees employee)
        {
            // Logic to update an Employee
        }
        // DELETE: api/Employee/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
        private List<Employees> GetEmployees()
        {
            return new List<Employees>()
        {
            new Employees()
            {
                Id = 1,
                FirstName= "John",
                LastName = "Smith",
                EmailId ="John.Smith@gmail.com"
            },
            new Employees()
            {
                Id = 2,
                FirstName= "Jane",
                LastName = "Doe",
                EmailId ="Jane.Doe@gmail.com"
            }
        };
        }
    }
}
